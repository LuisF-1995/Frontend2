let url = 'https://ctd-todo-api.herokuapp.com/v1/users';

let dataUser = {
    firstName: "Equipo",
    lastName: "9",
    email: "equipo9@email.com",
    password: '9equipoC4'
};

const settingsPOST = function (dataToJSON) {
    return {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataToJSON),
    }
}


fetch(url, settingsPOST(dataUser))
.then(data => data.json())
.then(response => console.log(response))
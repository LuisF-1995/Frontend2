let i = 0;
 let btn=document.getElementById("btn");
 btn.addEventListener("click",()=>{document.querySelector("p").innerHTML = ++i
 console.log(i)});

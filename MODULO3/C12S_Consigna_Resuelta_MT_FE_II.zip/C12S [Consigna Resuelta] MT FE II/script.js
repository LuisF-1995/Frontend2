const contenedorProductos = document.getElementById('productos')
const contenedorCarro = document.querySelector('#carro');
const nodoTotal = document.querySelector('#total');

let valorTotal = 0.0;


const productos = [
    {
        id: 1,
        nombre: "Producto 1",
        precio: 1500,
        img: "https://via.placeholder.com/250"
    },
    {
        id: 2,
        nombre: "Producto 2",
        precio: 2500,
        img: "https://via.placeholder.com/250"
    },
    {
        id: 3,
        nombre: "Producto 3",
        precio: 3500,
        img: "https://via.placeholder.com/250"
    },
    {
        id: 4,
        nombre: "Producto 4",
        precio: 4500,
        img: "https://via.placeholder.com/250"
    },
    {
        id: 5,
        nombre: "Producto 5",
        precio: 5500,
        img: "https://via.placeholder.com/250"
    },
    {
        id: 6,
        nombre: "Producto 6",
        precio: 6500,
        img: "https://via.placeholder.com/250"
    },
    {
        id: 7,
        nombre: "Producto 7",
        precio: 7500,
        img: "https://via.placeholder.com/250"
    },
]

let productosCarro = [];

productos.forEach((prod) => {

    // const div = document.createElement('div');
    // div.id = `producto${prod.id}`
    // div.setAttribute('id', 'producto');

    // TEMPLATE STRING
    contenedorProductos.innerHTML +=
        `<div id="producto-${prod.id}">
        <img src=${prod.img} />
        <h3 class="titulo">${prod.nombre}</h3>
        <p class="strong">Precio: $${prod.precio}</p>
        <p>Código: ${prod.id}</p>
        <button onclick="agregarAlCarro(${prod.id})">Agregar</button>
        </div>`;

    console.log(`iteración ${prod.id}`);
    // contenedorProductos.append(div)
});

function agregarAlCarro(productoId) {
    let producto = productos.find(p => p.id === productoId);
    productosCarro.unshift(producto);
    contenedorCarro.prepend(representarProductoEnCarro(producto));
    actualizarTotal(producto.precio);
}

function eliminarDelCarro(productoId) {
    let producto = productos.find(p => p.id === productoId);
    productosCarro.pop(producto);

    let productoARemover = document.querySelector(`#producto-carro-${productoId}`)
    contenedorCarro.removeChild(productoARemover);
    actualizarTotal(-producto.precio);
}

function representarProductoEnCarro(producto) {
    let nodoNuevoProducto = document.createElement('div');
    nodoNuevoProducto.setAttribute('id', `producto-carro-${producto.id}`)
    nodoNuevoProducto.innerHTML = 
    `<img src=${producto.img} />
    <h3 class="titulo">${producto.nombre}</h3>
    <p class="strong">Precio: $${producto.precio}</p>
    <button onclick="eliminarDelCarro(${producto.id})">Eliminar</button>`;
    return nodoNuevoProducto;
}

function actualizarTotal(precio) {
    valorTotal += precio;
    nodoTotal.innerHTML = `${valorTotal}`;
}